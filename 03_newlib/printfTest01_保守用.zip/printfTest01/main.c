#include "rpi_lib/rpi.h"
#include <stdio.h>

int main(void){
	rpi_init();
	char hoge[256];

	// GPIO16をOutputにセット
	pinMode(16,OUTPUT);
	// GPIO16をLにセット
	digitalWrite(16, LOW);

	while(1){
		// GPIO16をLにセット
		digitalWrite(16, LOW);
		printf("hello\n");
		// uart0_putc('A');
		// sprintf(hoge,"hello\n");
		// uart0_puts(hoge);
		delay(1000);
		// GPIO16をHにセット
		digitalWrite(16, HIGH);
		delay(1000);
		// delay(500);
	}
	
	return 0;
}
