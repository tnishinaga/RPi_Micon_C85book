// delay
void delayMicroseconds(unsigned int us);
void delay(unsigned int ms);
