#include "rpi.h"

void rpi_init(void){
	// jtag有効
/*	pinMode(4,ALT5);
	pinMode(22,ALT4);
	pinMode(24,ALT4);
	pinMode(25,ALT4);
	pinMode(27,ALT4);*/
	
	clearBss();
	// システムタイマーを初期化
	init_syst();
	// GPIOをすべてINPUT_PULLUPに設定
	init_gpio();

	// UARTを有効
	Serial_begin(115200);
}