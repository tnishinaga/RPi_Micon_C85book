volatile void clearBss(void){
	volatile extern void *__bss_start;
	volatile extern void *__bss_end;
	// unsigned int SectionLen = (void *)__bss_end - (void *)__bss_start;
	// volatile unsigned int loop;
	// volatile unsigned int *pulDest = (unsigned int*)&__bss_start;
	volatile unsigned int *p;
	volatile unsigned int *start = (unsigned int*)&__bss_start;
	volatile unsigned int *end = (unsigned int *)&__bss_end;

	// for(loop = 0;loop < SectionLen; loop+=4){
	// 	*pulDest = 0;
	// 	pulDest+=4;
	// }

	for(p = start;p < end; p++){
		*p = 0x00;
	}

}
