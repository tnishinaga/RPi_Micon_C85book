typedef volatile unsigned int vu32_t;
typedef volatile unsigned long long vu64_t;